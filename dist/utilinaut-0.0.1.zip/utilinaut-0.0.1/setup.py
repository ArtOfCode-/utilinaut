from distutils.core import setup
setup(
    name = 'utilinaut',
    packages = ['utilinaut'],
    version = '0.0.1',
    description = 'General utilities for use in Python scripting.',
    author = 'ArtOfCode',
    author_email = 'hello@artofcode.co.uk',
    url = 'https://github.com/ArtOfCode-/utilinaut',
    download_url = 'https://github.com/ArtOfCode-/utilinaut/tarball/0.0.1-minim'
)
